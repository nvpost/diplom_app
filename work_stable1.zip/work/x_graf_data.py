from datetime import datetime, timedelta


d_format = "%Y-%m-%d"


def delta_date(start_date, end_date, step=1):
    delta_date_ar = []
    deltadays = round(((end_date - start_date).days+1)/step)
    nd = start_date
    for i in range(deltadays):
        delta_date_ar.append(nd.strftime(d_format))
        nd = nd + timedelta(days=1)
    return(delta_date_ar)


