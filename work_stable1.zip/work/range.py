from datetime import datetime as dt
import dash
import dash_html_components as html
import dash_core_components as dcc


import render_graf
import available_fields as af

fd = af.fields_data

bars=list(fd.keys())[:5]

drop_down_data=[]
for i in fd:
    drop_down_data.append({'label': fd[i], 'value': i})


external_stylesheets = ['https://codepen.io/chriddyp/pen/bWLwgP.css']

d_format = "%Y-%m-%d"

app = dash.Dash(__name__, external_stylesheets=external_stylesheets)
app.layout = html.Div([
    dcc.DatePickerRange(
        id='my-date-picker-range',
        min_date_allowed=dt(2018, 11, 1),
        max_date_allowed=dt(2019, 12, 28),
        initial_visible_month=dt(2019, 10, 1),
        start_date=dt(2019, 10, 2),
        end_date=dt(2019, 10, 12),
        display_format='DD.MM.YY'
    ),
    dcc.Dropdown(
        id='my-dropdown',
        options=drop_down_data,
        multi=True,
        value=["users", "visits", "buyers", "idle", "goals"]
    ),


    html.Div(id='output-container-date-picker-range')
])


@app.callback(
    dash.dependencies.Output('output-container-date-picker-range', 'children'),
    [dash.dependencies.Input('my-date-picker-range', 'start_date'),
     dash.dependencies.Input('my-date-picker-range', 'end_date'),
        dash.dependencies.Input('my-dropdown', 'value')
     ]
)

def update_output(start_date, end_date, value):
        start_date = dt.strptime(start_date.split('T')[0], d_format)
        end_date = dt.strptime(end_date.split('T')[0], d_format)
        return render_graf.render_graf(start_date, end_date, value)




if __name__ == '__main__':
    app.run_server(debug=True)